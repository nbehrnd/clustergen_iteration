# name:   retain_doublettes.py
# author: nbehrnd@yahoo.com
# date:   2019-09-10 (YYYY-MM-DD)
# edit:   2019-09-11 (YYYY-MM-DD)
""" retain only lines about plausible doublettes in report_work.txt

Past working with multiproArles.py about the 1953 tests performed, there
are 612 probably indicating a doublette.  Only these entries shall be
retained and written into a file 'doublettes.txt'. """
import sys
register = []

if len(sys.argv[1]) > 0:
    work_file = str(sys.argv[1])
else:
    print("Expected use:\n    python3 [example.txt]")
    print("with mandatory parameter to indicate the file to work on.")
    print("No data modified, the script closes now.")
    sys.exit(0)

with open(work_file, mode="r") as source:
    for line in source:
        retain = str(line).strip()
        register.append(retain)
register.sort()

with open("doublettes.csv", mode="w") as newfile:
    for entry in register:
        if entry.endswith("e-15"):
            retain = str("{}\n".format(entry))
            newfile.write(retain)

sys.exit()
