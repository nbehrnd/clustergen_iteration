#!/usr/bin/env python3
# name:   multipro.py
# author: nbehrnd@yahoo.com
# edit:   2019-Apr-02

"""
Engage calculate_rmsdArles.py simultaneously on many *.xyz and multiple CPUs

Allow the concurrent, parallel run of calculate_rmsd.py.  Assumes
Python3 as the engine.  To perform well, this script and relayed
calculate_rmsd.py must reside in the same directory -- this proof
of concept does not consider an os.walk.  Launch by

python multiproArles.py
"""

import os
import shutil
import sys
import subprocess as sub
from multiprocessing import Pool as ThreadPool
import time
fileRegister = []
testRegister = []


def greeter():
    """
    Time stamp, purpose, limit
    """
    if sys.version_info.major == 2:
        print("\n" + str(time.strftime("%d-%b-%Y").rjust(67)) + "\n")
    if sys.version_info.major == 3:
        print(("\n" + str(time.strftime("%d-%b-%Y").rjust(67)) + "\n"))
    print("\nModerator script 'multiproArles.py', parallel RMSD scrutiny.")
    print("Requires modified 'calculate_rmsdArles.py' and its '__init__.py'.")
    print("If called with Python2, the scrutiny will be linear (GIL).")
    print("If called with Python3, the scrutiny partially is parallelized.")


def fileSearch():
    """
    detects the *.xyz files
    """
    global fileRegister
    for file in os.listdir("."):
        if file.endswith(".xyz"):
            fileRegister.append(file)
    fileRegister.sort()
    return fileRegister


def modeSelection():
    """
    decide for either Kabsch / quaternion test
    """
    # selection of the test method
    print("\nMethod selection. Choose one of the following:")
    print("[0]  To quit the script altogether.")
    print("[2]  To perform the Kabsch test.")
    print("[4]  To perform the Quaternion test.")

    global testMethod
    if sys.version_info.major == 2:
        testMethod = input()
    if sys.version_info.major == 3:
        testMethod = eval(input())

    if testMethod == 0:
        print("The program will close now.")
        sys.exit()
    if testMethod == 2:
        print("Kabsch test was selected.")
        testMethod = str(" -r kabsch ")
    if testMethod == 4:
        print("Test by quaternion was selected.")
        testMethod = str(" -r quaternion ")
    return testMethod


def inversion():
    # selection of the stereoMethod
    print("\nHow to handle the stereo options?  Either")
    print("[0]  Quit.")
    print("[1]  Permission to alter the stereo center (--use-reflection).")
    print("[2]  Retain the stereo information (--use-reflection-keep-stereo).")

    global stereoMethod
    if sys.version_info.major == 2:
        stereoMethod = input()
    if sys.version_info.major == 3:
        stereoMethod = eval(input())
    if stereoMethod == 0:
        sys.exit()

    if stereoMethod == 1:
        print("Test may test enantionmers generated 'on the fly'.")
        stereoMethod = str(" --use-reflections ")
    if stereoMethod == 2:
        print("Only even numbered reflections will be applied.")
        stereoMethod = str(" --use-reflections-keep-stereo ")
    return stereoMethod


def constructCommand():
    """
    builds the commands eventually relayed to calculate_rmsd.py
    """
    global testRegister
    while len(fileRegister) > 1:
        for entry in fileRegister[1:]:
            m0 = str(fileRegister[0])
            m1 = str(entry)

            # Previously named 20190328-modified-calculate_rmsd.py was
            # renamed -- for consistency -- to calculate_rmsdArles.py.
            # Other than the original, it provides reflection based-RMSD
            # and new coordinates of modelB in one single test for
            # `--use-reflections(-keep-stereo) -p`.  calculate_rmsdArles.py
            # equally differs in detail from the feature suggestion at
            # Jimmy Charnley's GitHub page deposit earlier.
            command = str("python calculate_rmsdArles.py ") +\
                      str(m0) + str(" ") + str(m1) +\
                      str(testMethod) + str(stereoMethod) +\
                      str(" --reorder --print")

            testRegister.append(str(command))
        del fileRegister[0]
    testRegister.sort()
    return testRegister


def spaceCleaning():
    """
    clean current working directory, move files worked with
    """
    os.mkdir("probeXyz")

    for file in os.listdir("."):
        if file.endswith(".xyz"):
            if str("testedWith") not in str(file):
                shutil.move(file, "probeXyz")


# method application, 1st section
greeter()
fileSearch()

modeSelection()
inversion()
constructCommand()


def test(testRegister):
    """
    relay the test to multiple CPU instances of calculate_rmsd.py
    """
    sub.call(testRegister, shell=True)


if sys.version_info.major == 2:
    def testing(data=""):
        """
        relay the test to calculate_rmsd.py

        This is the GIL limited, linear / single CPU core approach.
        """
        for entry in testRegister:
            sub.call(entry, shell=True)

    testing()

if sys.version_info.major == 3:
    """
    benefit from possible parallel approach w/ multiple CPU
    """
    workers = os.cpu_count() - 1  # conservative approach, keeping some reserve
    pool = ThreadPool(workers)  # maximal number of tests performed in parallel
    pool.starmap(test, zip(testRegister))
    pool.close()
    pool.join()


spaceCleaning()
print("\nScript 'multiproArles.py' closes now.")
sys.exit(0)
